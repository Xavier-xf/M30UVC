/*
 * uvc_m30.h  -  M30 UVC 封装层公开接口
 *
 *   纯 C 兼容、线程安全的最小可用框架，覆盖：
 *     生命周期 / 设备信息 / 视频流配置 / 拉帧 / 开关控制
 *
 *   设计要点：
 *     - 不透明上下文，无全局状态
 *     - uvc_open() 分阶段提交 + 完整回滚
 *     - 统一 UVC_ERR_* 错误码，uvc_strerror() 可读描述
 */

#ifndef UVC_M30_H
#define UVC_M30_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ------------------------------------------------------------------------ */
/*  错误码                                                                   */
/* ------------------------------------------------------------------------ */
#define UVC_OK                        0
#define UVC_ERR_INVAL                -1    /* 无效参数                       */
#define UVC_ERR_NOMEM                -2    /* 内存分配失败                   */
#define UVC_ERR_STATE                -3    /* 当前状态不允许此操作           */
#define UVC_ERR_NO_DEVICE            -4    /* 未检测到 M30 设备              */
#define UVC_ERR_MULTI_DEVICE         -5    /* 检测到多台 M30 设备            */
#define UVC_ERR_SDK_INIT             -6    /* 厂商 SDK Init() 失败           */
#define UVC_ERR_SDK_CALL             -7    /* 厂商 SDK 接口调用失败          */
#define UVC_ERR_SERIAL               -8    /* 串口连接异常                   */
#define UVC_ERR_CAMERA               -9    /* UVC 视频连接异常               */
#define UVC_ERR_TIMEOUT             -10    /* 通信超时                       */
#define UVC_ERR_IO                  -11    /* 文件/文件系统错误              */
#define UVC_ERR_BUSY                -12    /* 操作冲突/资源被占用            */

/* ------------------------------------------------------------------------ */
/*  枚举类型                                                                 */
/* ------------------------------------------------------------------------ */

/* 操作目标摄像头选择                                                        */
typedef enum {
    UVC_CAM_RGB            = 0,   /* RGB 可见光摄像头                        */
    UVC_CAM_IR             = 1,   /* IR 红外摄像头                           */
} uvc_cam_t;

/* ------------------------------------------------------------------------ */
/*  数据类型                                                                 */
/* ------------------------------------------------------------------------ */

/* 不透明上下文句柄 */
typedef struct uvc_ctx uvc_ctx_t;

/* 原始帧描述符，由 uvc_get_frame() 填充                                    */
typedef struct {
    uint8_t  *data;      /* 指向调用者提供的缓冲区                           */
    size_t    size;      /* 有效载荷字节数                                   */
    int       width;     /* 帧宽度（像素）                                   */
    int       height;    /* 帧高度（像素）                                   */
    char      verify[2048]; /* SDK 返回的校验/元数据字符串                    */
} uvc_frame_t;

/* 创建选项；字段为 0 时使用安全默认值                                       */
typedef struct {
    int       log_level;     /* 0=TRACE .. 5=FATAL, 6=关闭 (默认: 2=INFO)    */
    int       log_target;    /* 0=控制台, 1=文件, 2=两者    (默认: 2)        */
    int       connect_timeout_ms; /* 连接超时，Ping 重试预算 (默认: 3000ms)  */
} uvc_config_t;

/* ------------------------------------------------------------------------ */
/*  生命周期管理                                                             */
/* ------------------------------------------------------------------------ */

void        uvc_default_config(uvc_config_t *cfg);
uvc_ctx_t  *uvc_create(const uvc_config_t *cfg);
void        uvc_destroy(uvc_ctx_t *ctx);
int         uvc_open(uvc_ctx_t *ctx);
int         uvc_close(uvc_ctx_t *ctx);
int         uvc_is_open(const uvc_ctx_t *ctx);
const char *uvc_strerror(int err);
void        uvc_shutdown_hook(uvc_ctx_t *ctx);

/* ------------------------------------------------------------------------ */
/*  设备信息查询                                                             */
/* ------------------------------------------------------------------------ */

int uvc_ping            (uvc_ctx_t *ctx);
int uvc_get_version     (uvc_ctx_t *ctx, char *buf, size_t len);
int uvc_get_sn          (uvc_ctx_t *ctx, char *buf, size_t len);
int uvc_get_model       (uvc_ctx_t *ctx, char *buf, size_t len);
int uvc_get_cpu_temp    (uvc_ctx_t *ctx, unsigned int *temp_c);

/* ------------------------------------------------------------------------ */
/*  视频流配置 / 开关控制                                                    */
/* ------------------------------------------------------------------------ */

int uvc_get_resolution  (uvc_ctx_t *ctx, int *w, int *h);
int uvc_get_framerate   (uvc_ctx_t *ctx, unsigned int *fps);

/** UVC 视频输出总开关，on=1 开启, on=0 关闭 */
int uvc_set_uvc_switch  (uvc_ctx_t *ctx, int on);

/** 打开/关闭指定摄像头，cam=UVC_CAM_RGB/IR，on=1 打开, on=0 关闭 */
int uvc_camera_stream   (uvc_ctx_t *ctx, uvc_cam_t cam, int on);

/** 查询指定摄像头开关状态，is_open 输出 1=已打开, 0=已关闭 */
int uvc_get_camera_stream(uvc_ctx_t *ctx, uvc_cam_t cam, int *is_open);

/* ------------------------------------------------------------------------ */
/*  视频帧捕获                                                               */
/* ------------------------------------------------------------------------ */

/**
 * uvc_get_frame - 从 UVC 流中拉取一帧 BGRA 数据
 * 调用者需提供至少 width*height*4 字节的缓冲区
 */
int uvc_get_frame(uvc_ctx_t *ctx, void *buf, size_t buf_size,
                  uvc_frame_t *out);

/** uvc_save_frame_bmp - 抓取一帧并保存为 32 位 BMP 文件 */
int uvc_save_frame_bmp(uvc_ctx_t *ctx, const char *path);

#ifdef __cplusplus
}
#endif

#endif /* UVC_M30_H */
