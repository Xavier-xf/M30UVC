/*
 * main.c  -  M30 UVC 封装层交互式测试程序（基础框架）
 *
 *   覆盖：连接 / 设备信息 / 拉帧 / 开关控制
 *   设计为 ssh / 串口控制台驱动，无需图形环境
 */

#include "uvc_m30.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>

static volatile sig_atomic_t g_quit = 0;
static volatile sig_atomic_t g_stop = 0;
static uvc_ctx_t            *g_ctx  = NULL;

static void on_signal(int sig)
{
    (void)sig;
    g_quit = 1;
    g_stop = 1;
}

static int read_line(char *buf, size_t len)
{
    if (!fgets(buf, (int)len, stdin)) return -1;
    size_t n = strlen(buf);
    while (n > 0 && (buf[n - 1] == '\n' || buf[n - 1] == '\r')) buf[--n] = 0;
    return 0;
}

static long long now_ms(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

/* -------------------- 连续拉流 --------------------- */

static void stream_loop(uvc_ctx_t *ctx)
{
    int w = 0, h = 0;
    int err = uvc_get_resolution(ctx, &w, &h);
    if (err != UVC_OK) {
        printf("获取分辨率失败: %s\n", uvc_strerror(err));
        return;
    }

    size_t buf_size = (size_t)w * (size_t)h * 4u;
    unsigned char *buf = (unsigned char *)malloc(buf_size);
    if (!buf) {
        puts("帧缓冲区分配失败");
        return;
    }

    printf("开始连续拉流 %dx%d (BGRA, %zu 字节)\n", w, h, buf_size);
    printf("每秒保存一帧 BMP，按 Ctrl+C 停止...\n\n");

    g_stop = 0;
    uvc_frame_t fr;
    unsigned long frame_cnt    = 0;
    unsigned long total_frames = 0;
    unsigned long err_cnt      = 0;
    unsigned int  save_idx     = 0;
    long long t_start    = now_ms();
    long long t_last     = t_start;
    long long t_last_save = t_start;

    while (!g_stop) {
        err = uvc_get_frame(ctx, buf, buf_size, &fr);
        if (err == UVC_OK) {
            frame_cnt++;
            total_frames++;

            long long t_now = now_ms();
            if (t_now - t_last_save >= 1000) {
                char path[64];
                snprintf(path, sizeof(path), "./stream_%04u.bmp", save_idx++);
                if (uvc_save_frame_bmp(ctx, path) == UVC_OK)
                    printf("\n  [保存] %s (%dx%d)\n", path, fr.width, fr.height);
                t_last_save = t_now;
            }
        } else {
            err_cnt++;
            if (err_cnt <= 3)
                printf("  拉帧失败: %s\n", uvc_strerror(err));
        }

        long long t_now = now_ms();
        long long elapsed = t_now - t_last;
        if (elapsed >= 1000) {
            double fps = frame_cnt * 1000.0 / elapsed;
            double avg = total_frames * 1000.0 / (t_now - t_start);
            printf("\r  帧数: %lu | %.1f fps | 平均 %.1f fps | 已存 %u | 错误: %lu    ",
                   total_frames, fps, avg, save_idx, err_cnt);
            fflush(stdout);
            frame_cnt = 0;
            t_last = t_now;
        }
    }

    long long t_total = now_ms() - t_start;
    printf("\n\n拉流结束: %lu 帧, %.1f 秒, 平均 %.1f fps, 错误 %lu\n",
           total_frames, t_total / 1000.0,
           t_total > 0 ? total_frames * 1000.0 / t_total : 0.0, err_cnt);

    free(buf);
    g_stop = 0;
    g_quit = 0;
}

/* -------------------- 菜单 --------------------- */

static void show_menu(void)
{
    puts("");
    puts("========== M30 基础框架测试 ==========");
    puts("  0) Ping 探活");
    puts("  1) 设备信息 (版本/SN/型号/温度)");
    puts("  2) 查询分辨率 / 帧率");
    puts("  3) 保存单帧 BMP  (./frame.bmp)");
    puts("  4) 连续拉流 (Ctrl+C 停止)");
    puts("  5) UVC 输出开关 (1=开 0=关)");
    puts("  6) 摄像头开关 (RGB/IR)");
    puts("  7) 查询摄像头状态");
    puts(" 99) 退出");
    printf(" > ");
    fflush(stdout);
}

int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_signal;
    sigaction(SIGINT,  &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);

    uvc_config_t cfg;
    uvc_default_config(&cfg);
    cfg.log_level = 1;   /* DEBUG */

    g_ctx = uvc_create(&cfg);
    if (!g_ctx) {
        fprintf(stderr, "uvc_create 失败\n");
        return 1;
    }

    int err = uvc_open(g_ctx);
    if (err != UVC_OK) {
        fprintf(stderr, "uvc_open 失败: %s (%d)\n", uvc_strerror(err), err);
        uvc_destroy(g_ctx);
        return 2;
    }
    printf("M30 连接成功。\n");

    char line[256];
    while (!g_quit) {
        show_menu();
        if (read_line(line, sizeof(line)) != 0) break;
        int ch = atoi(line);

        switch (ch) {
        case 0:
            err = uvc_ping(g_ctx);
            printf("[PING] %s\n", err == UVC_OK ? "通过" : uvc_strerror(err));
            break;

        case 1: {
            char ver[128] = {0}, sn[128] = {0}, model[128] = {0};
            unsigned int tc = 0;
            (void)uvc_get_version (g_ctx, ver,   sizeof(ver));
            (void)uvc_get_sn     (g_ctx, sn,    sizeof(sn));
            (void)uvc_get_model  (g_ctx, model, sizeof(model));
            (void)uvc_get_cpu_temp(g_ctx, &tc);
            printf("版本: %s\nSN  : %s\n型号: %s\n温度: %u°C\n",
                   ver, sn, model, tc);
            break;
        }

        case 2: {
            int w = 0, h = 0;
            unsigned int fps = 0;
            if (uvc_get_resolution(g_ctx, &w, &h) == UVC_OK)
                printf("分辨率: %dx%d\n", w, h);
            if (uvc_get_framerate(g_ctx, &fps) == UVC_OK)
                printf("帧率  : %u fps\n", fps);
            break;
        }

        case 3:
            err = uvc_save_frame_bmp(g_ctx, "./frame.bmp");
            printf("[BMP] %s\n",
                   err == UVC_OK ? "已保存 frame.bmp" : uvc_strerror(err));
            break;

        case 4:
            stream_loop(g_ctx);
            break;

        case 5:
            printf("UVC 输出 (1=开 0=关): "); fflush(stdout);
            if (read_line(line, sizeof(line))) break;
            err = uvc_set_uvc_switch(g_ctx, atoi(line));
            printf("[UVC] %s\n", err == UVC_OK ? "通过" : uvc_strerror(err));
            break;

        case 6: {
            printf("摄像头 (0=RGB 1=IR): "); fflush(stdout);
            if (read_line(line, sizeof(line))) break;
            int cam = atoi(line);
            printf("操作 (1=打开 0=关闭): "); fflush(stdout);
            if (read_line(line, sizeof(line))) break;
            err = uvc_camera_stream(g_ctx, (uvc_cam_t)cam, atoi(line));
            printf("[摄像头] %s\n", err == UVC_OK ? "通过" : uvc_strerror(err));
            break;
        }

        case 7: {
            int rgb = 0, ir = 0;
            int r1 = uvc_get_camera_stream(g_ctx, UVC_CAM_RGB, &rgb);
            int r2 = uvc_get_camera_stream(g_ctx, UVC_CAM_IR,  &ir);
            if (r1 == UVC_OK && r2 == UVC_OK)
                printf("RGB: %s  |  IR: %s\n",
                       rgb ? "开" : "关", ir ? "开" : "关");
            else
                printf("查询失败\n");
            break;
        }

        case 99:
            g_quit = 1;
            break;

        default:
            puts("无效选项");
        }
    }

    printf("\n关闭连接...\n");
    uvc_shutdown_hook(g_ctx);
    uvc_destroy(g_ctx);
    return 0;
}
