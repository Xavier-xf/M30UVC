/*
 * uvc_m30.c  -  M30 UVC 封装层实现（基础框架）
 *
 *   覆盖：生命周期（分阶段提交 + 回滚）/ 设备信息 / 拉帧 / 开关控制
 *   仅通过 m30_sdk.h 纯 C 声明引用厂商 SDK
 */

#include "uvc_m30.h"
#include "uvc_log.h"
#include "uvc_bmp.h"
#include "m30_sdk.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

/* ------------------------------------------------------------------------ */
/*  可调参数                                                                 */
/* ------------------------------------------------------------------------ */
#define UVC_PING_PAYLOAD          "ping"
#define UVC_FRAME_WAIT_MS         200      /* 每次重试等待（毫秒）           */
#define UVC_FRAME_MAX_RETRIES     25       /* 最大重试次数（约 5 秒超时）    */
#define UVC_VIDEO_NODES_MAX       8        /* 候选视频节点最大数量           */

/* ------------------------------------------------------------------------ */
/*  上下文结构体                                                             */
/* ------------------------------------------------------------------------ */
struct uvc_ctx {
    void            *sdk_dev;             /* Init() 返回的厂商句柄          */
    pthread_mutex_t  lock;                /* 递归互斥锁                     */
    uvc_config_t     cfg;                 /* 用户配置副本                   */

    char             video_nodes[UVC_VIDEO_NODES_MAX][128];
    int              video_node_count;
    char             video_node[128];     /* 实际连通的视频节点             */
    char             serial_node[128];    /* 串口设备节点                   */

    int              sdk_inited;
    int              serial_up;
    int              camera_up;
};

/* ------------------------------------------------------------------------ */
/*  错误码转换                                                               */
/* ------------------------------------------------------------------------ */
static int map_sdk_err(int rc)
{
    if (rc == AC_ERR_SUCCESS) return UVC_OK;
    switch (rc) {
    case AC_ERR_NOT_INIT:
    case AC_ERR_ALREADY_INIT:              return UVC_ERR_STATE;
    case AC_ERR_INIT_FAIL:                 return UVC_ERR_SDK_INIT;
    case AC_ERR_INPUT_ARG:
    case AC_ERR_OUTPUT_ARG:                return UVC_ERR_INVAL;
    case AC_ERR_COM_TIMEOUT:               return UVC_ERR_TIMEOUT;
    case AC_ERR_UVC_CONNECT:
    case AC_ERR_UVC_NEWFRAME_UNARRIVE:     return UVC_ERR_CAMERA;
    case AC_ERR_SERIAL_CONNECT:            return UVC_ERR_SERIAL;
    default:                               return UVC_ERR_SDK_CALL;
    }
}

const char *uvc_strerror(int err)
{
    switch (err) {
    case UVC_OK:                 return "成功";
    case UVC_ERR_INVAL:          return "无效参数";
    case UVC_ERR_NOMEM:          return "内存不足";
    case UVC_ERR_STATE:          return "状态无效";
    case UVC_ERR_NO_DEVICE:      return "未找到设备";
    case UVC_ERR_MULTI_DEVICE:   return "检测到多台设备";
    case UVC_ERR_SDK_INIT:       return "SDK 初始化失败";
    case UVC_ERR_SDK_CALL:       return "SDK 调用失败";
    case UVC_ERR_SERIAL:         return "串口链路错误";
    case UVC_ERR_CAMERA:         return "UVC 链路错误";
    case UVC_ERR_TIMEOUT:        return "通信超时";
    case UVC_ERR_IO:             return "I/O 错误";
    case UVC_ERR_BUSY:           return "资源被占用";
    default:                     return "未知错误";
    }
}

/* ------------------------------------------------------------------------ */
/*  加锁辅助宏                                                               */
/* ------------------------------------------------------------------------ */
#define LOCK(c)    pthread_mutex_lock  (&(c)->lock)
#define UNLOCK(c)  pthread_mutex_unlock(&(c)->lock)

#define RETURN_UNLOCK(c, v)                \
    do { int _r = (v); UNLOCK(c); return _r; } while (0)

#define REQUIRE_OPEN_UNLOCK(c)                          \
    do {                                                \
        if (!uvc_is_open(c)) { UNLOCK(c); return UVC_ERR_STATE; } \
    } while (0)

/* SDK 调用简化宏 */
#define SDK_CALL_SIMPLE(ctx, expr)                                      \
    do {                                                                \
        if (!(ctx)) return UVC_ERR_INVAL;                               \
        LOCK(ctx);                                                      \
        REQUIRE_OPEN_UNLOCK(ctx);                                       \
        int _rc = (expr);                                               \
        RETURN_UNLOCK(ctx, map_sdk_err(_rc));                           \
    } while (0)

/* ------------------------------------------------------------------------ */
/*  默认配置                                                                 */
/* ------------------------------------------------------------------------ */
void uvc_default_config(uvc_config_t *cfg)
{
    if (!cfg) return;
    cfg->log_level          = 2;     /* INFO */
    cfg->log_target         = 2;     /* 控制台+文件 */
    cfg->connect_timeout_ms = 3000;
}

/* ------------------------------------------------------------------------ */
/*  生命周期                                                                 */
/* ------------------------------------------------------------------------ */

uvc_ctx_t *uvc_create(const uvc_config_t *cfg)
{
    uvc_ctx_t *c = (uvc_ctx_t *)calloc(1, sizeof(*c));
    if (!c) return NULL;

    if (cfg) c->cfg = *cfg;
    else     uvc_default_config(&c->cfg);

    pthread_mutexattr_t attr;
    if (pthread_mutexattr_init(&attr) != 0) {
        free(c);
        return NULL;
    }
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    if (pthread_mutex_init(&c->lock, &attr) != 0) {
        pthread_mutexattr_destroy(&attr);
        free(c);
        return NULL;
    }
    pthread_mutexattr_destroy(&attr);

    int rc = SetLogConfig(c->cfg.log_level, c->cfg.log_target);
    if (rc != 0)
        UVC_LOGW("SetLogConfig(level=%d,target=%d) rc=%d",
                 c->cfg.log_level, c->cfg.log_target, rc);

    UVC_LOGI("M30 上下文已创建");
    return c;
}

void uvc_destroy(uvc_ctx_t *ctx)
{
    if (!ctx) return;
    (void)uvc_close(ctx);
    pthread_mutex_destroy(&ctx->lock);
    free(ctx);
}

int uvc_is_open(const uvc_ctx_t *ctx)
{
    return ctx && ctx->sdk_inited && ctx->serial_up && ctx->camera_up;
}

static int split_nodes(const char *list, char out[][128], int max)
{
    int count = 0;
    const char *p = list;
    while (*p && count < max) {
        const char *sep = strchr(p, '|');
        size_t n = sep ? (size_t)(sep - p) : strlen(p);
        if (n > 0 && n < 128) {
            memcpy(out[count], p, n);
            out[count][n] = '\0';
            count++;
        }
        if (!sep) break;
        p = sep + 1;
    }
    return count;
}

static int enumerate_single(uvc_ctx_t *ctx)
{
    char vid[1024];
    char ser[1024];
    vid[0] = ser[0] = '\0';

    int rc = EnumDevice(vid, (int)sizeof(vid), ser, (int)sizeof(ser));
    if (rc != 0) {
        UVC_LOGE("EnumDevice 失败 rc=%d", rc);
        return UVC_ERR_SDK_CALL;
    }
    if (vid[0] == '\0' || ser[0] == '\0') {
        UVC_LOGE("未发现 M30 设备");
        return UVC_ERR_NO_DEVICE;
    }

    if (strchr(ser, '|')) {
        UVC_LOGE("检测到多台 M30 设备: serial=%s", ser);
        return UVC_ERR_MULTI_DEVICE;
    }

    ctx->video_node_count = split_nodes(vid, ctx->video_nodes,
                                        UVC_VIDEO_NODES_MAX);
    if (ctx->video_node_count == 0) {
        UVC_LOGE("未解析到有效的视频节点");
        return UVC_ERR_NO_DEVICE;
    }
    snprintf(ctx->serial_node, sizeof(ctx->serial_node), "%s", ser);

    UVC_LOGI("M30 枚举成功  serial=%s  video候选(%d个): %s",
             ctx->serial_node, ctx->video_node_count, vid);
    return UVC_OK;
}

int uvc_open(uvc_ctx_t *ctx)
{
    if (!ctx) return UVC_ERR_INVAL;
    LOCK(ctx);
    if (uvc_is_open(ctx)) RETURN_UNLOCK(ctx, UVC_OK);

    int err = enumerate_single(ctx);
    if (err != UVC_OK) RETURN_UNLOCK(ctx, err);

    /* SDK 初始化 */
    ctx->sdk_dev = Init();
    if (!ctx->sdk_dev) {
        UVC_LOGE("SDK Init() 返回 NULL");
        RETURN_UNLOCK(ctx, UVC_ERR_SDK_INIT);
    }
    ctx->sdk_inited = 1;

    /* 连接串口 */
    int rc = ConnectSerial(ctx->sdk_dev, ctx->serial_node);
    if (rc != 0) {
        UVC_LOGE("ConnectSerial(%s) 失败 rc=%d", ctx->serial_node, rc);
        err = map_sdk_err(rc);
        goto rollback_sdk;
    }
    ctx->serial_up = 1;

    /* 连接 UVC 摄像头（逐一尝试候选视频节点） */
    {
        int cam_ok = 0;
        for (int i = 0; i < ctx->video_node_count; ++i) {
            rc = ConnectCamera(ctx->sdk_dev, ctx->video_nodes[i]);
            if (rc == 0) {
                snprintf(ctx->video_node, sizeof(ctx->video_node),
                         "%s", ctx->video_nodes[i]);
                UVC_LOGI("ConnectCamera(%s) 成功 (第%d/%d个候选)",
                         ctx->video_node, i + 1, ctx->video_node_count);
                cam_ok = 1;
                break;
            }
            UVC_LOGW("ConnectCamera(%s) 失败 rc=%d, 尝试下一个",
                     ctx->video_nodes[i], rc);
        }
        if (!cam_ok) {
            UVC_LOGE("所有候选视频节点均连接失败");
            err = UVC_ERR_CAMERA;
            goto rollback_serial;
        }
    }
    ctx->camera_up = 1;

    /* Ping 链路探活 */
    rc = Ping(ctx->sdk_dev,
              UVC_PING_PAYLOAD, (unsigned int)strlen(UVC_PING_PAYLOAD));
    if (rc != 0) {
        UVC_LOGE("Ping 失败 rc=%d", rc);
        err = UVC_ERR_TIMEOUT;
        goto rollback_camera;
    }

    UVC_LOGI("uvc_open 成功");
    RETURN_UNLOCK(ctx, UVC_OK);

rollback_camera:
    (void)DisconnectCamera(ctx->sdk_dev);
    ctx->camera_up = 0;
rollback_serial:
    (void)DisconnectSerial(ctx->sdk_dev);
    ctx->serial_up = 0;
rollback_sdk:
    (void)DeInit(ctx->sdk_dev);
    ctx->sdk_dev    = NULL;
    ctx->sdk_inited = 0;
    RETURN_UNLOCK(ctx, err);
}

int uvc_close(uvc_ctx_t *ctx)
{
    if (!ctx) return UVC_ERR_INVAL;
    LOCK(ctx);

    int first_err = UVC_OK;

    if (ctx->camera_up) {
        int rc = DisconnectCamera(ctx->sdk_dev);
        if (rc != 0 && first_err == UVC_OK) first_err = map_sdk_err(rc);
        ctx->camera_up = 0;
    }
    if (ctx->serial_up) {
        int rc = DisconnectSerial(ctx->sdk_dev);
        if (rc != 0 && first_err == UVC_OK) first_err = map_sdk_err(rc);
        ctx->serial_up = 0;
    }
    if (ctx->sdk_inited) {
        int rc = DeInit(ctx->sdk_dev);
        if (rc != 0 && first_err == UVC_OK) first_err = map_sdk_err(rc);
        ctx->sdk_dev    = NULL;
        ctx->sdk_inited = 0;
    }

    if (first_err == UVC_OK) UVC_LOGI("uvc_close 完成");
    else                     UVC_LOGW("uvc_close 有错误 rc=%d (%s)",
                                      first_err, uvc_strerror(first_err));
    RETURN_UNLOCK(ctx, first_err);
}

void uvc_shutdown_hook(uvc_ctx_t *ctx)
{
    if (!ctx) return;
    (void)uvc_close(ctx);
}

/* ------------------------------------------------------------------------ */
/*  设备信息查询                                                             */
/* ------------------------------------------------------------------------ */

int uvc_ping(uvc_ctx_t *ctx)
{
    SDK_CALL_SIMPLE(ctx, Ping(ctx->sdk_dev,
                              UVC_PING_PAYLOAD,
                              (unsigned int)strlen(UVC_PING_PAYLOAD)));
}

int uvc_get_version(uvc_ctx_t *ctx, char *buf, size_t len)
{
    if (!ctx || !buf || !len) return UVC_ERR_INVAL;
    LOCK(ctx);
    REQUIRE_OPEN_UNLOCK(ctx);
    memset(buf, 0, len);
    int rc = GetDeviceVersion(ctx->sdk_dev, buf, (unsigned int)len);
    RETURN_UNLOCK(ctx, map_sdk_err(rc));
}

int uvc_get_sn(uvc_ctx_t *ctx, char *buf, size_t len)
{
    if (!ctx || !buf || !len) return UVC_ERR_INVAL;
    LOCK(ctx);
    REQUIRE_OPEN_UNLOCK(ctx);
    memset(buf, 0, len);
    int rc = GetDevSn(ctx->sdk_dev, 0, buf, (unsigned int)len);
    RETURN_UNLOCK(ctx, map_sdk_err(rc));
}

int uvc_get_model(uvc_ctx_t *ctx, char *buf, size_t len)
{
    if (!ctx || !buf || !len) return UVC_ERR_INVAL;
    LOCK(ctx);
    REQUIRE_OPEN_UNLOCK(ctx);
    memset(buf, 0, len);
    int rc = GetDevModel(ctx->sdk_dev, buf, (unsigned int)len);
    RETURN_UNLOCK(ctx, map_sdk_err(rc));
}

int uvc_get_cpu_temp(uvc_ctx_t *ctx, unsigned int *temp_c)
{
    if (!ctx || !temp_c) return UVC_ERR_INVAL;
    LOCK(ctx);
    REQUIRE_OPEN_UNLOCK(ctx);
    int rc = GetCpuTemperature(ctx->sdk_dev, temp_c);
    RETURN_UNLOCK(ctx, map_sdk_err(rc));
}

/* ------------------------------------------------------------------------ */
/*  视频流配置 / 开关控制                                                    */
/* ------------------------------------------------------------------------ */

int uvc_get_resolution(uvc_ctx_t *ctx, int *w, int *h)
{
    if (!ctx || !w || !h) return UVC_ERR_INVAL;
    LOCK(ctx);
    REQUIRE_OPEN_UNLOCK(ctx);
    *w = *h = 0;
    int rc = GetResolution(ctx->sdk_dev, w, h);
    RETURN_UNLOCK(ctx, map_sdk_err(rc));
}

int uvc_get_framerate(uvc_ctx_t *ctx, unsigned int *fps)
{
    if (!ctx || !fps) return UVC_ERR_INVAL;
    LOCK(ctx);
    REQUIRE_OPEN_UNLOCK(ctx);
    int rc = GetFrameRate(ctx->sdk_dev, fps);
    RETURN_UNLOCK(ctx, map_sdk_err(rc));
}

/* SDK 语义反转：nMode=0 开启，nMode=1 关闭 */
int uvc_set_uvc_switch(uvc_ctx_t *ctx, int on)
{
    SDK_CALL_SIMPLE(ctx, SetUvcSwitch(ctx->sdk_dev, on ? 0 : 1));
}

int uvc_camera_stream(uvc_ctx_t *ctx, uvc_cam_t cam, int on)
{
    /* SDK 语义反转：0=打开，1=关闭 */
    SDK_CALL_SIMPLE(ctx, SetCameraStream(ctx->sdk_dev,
                                         on ? 0 : 1, (char)cam));
}

int uvc_get_camera_stream(uvc_ctx_t *ctx, uvc_cam_t cam, int *is_open)
{
    if (!ctx || !is_open) return UVC_ERR_INVAL;
    LOCK(ctx);
    REQUIRE_OPEN_UNLOCK(ctx);
    unsigned char state = 0;
    int rc = GetCameraStream(ctx->sdk_dev, (char)cam, &state);
    *is_open = state ? 1 : 0;
    RETURN_UNLOCK(ctx, map_sdk_err(rc));
}

/* ------------------------------------------------------------------------ */
/*  视频帧捕获                                                               */
/* ------------------------------------------------------------------------ */

int uvc_get_frame(uvc_ctx_t *ctx, void *buf, size_t buf_size,
                  uvc_frame_t *out)
{
    if (!ctx || !buf || !out || buf_size == 0) return UVC_ERR_INVAL;
    LOCK(ctx);
    REQUIRE_OPEN_UNLOCK(ctx);

    int w = 0, h = 0;
    int rc = GetResolution(ctx->sdk_dev, &w, &h);
    if (rc != 0 || w <= 0 || h <= 0) {
        UVC_LOGE("GetResolution 失败 rc=%d w=%d h=%d", rc, w, h);
        RETURN_UNLOCK(ctx, map_sdk_err(rc ? rc : AC_ERR_OUTPUT_ARG));
    }

    const size_t need = (size_t)w * (size_t)h * 4u;
    if (need > buf_size) {
        UVC_LOGE("帧缓冲区不足: 需要=%zu 实际=%zu", need, buf_size);
        RETURN_UNLOCK(ctx, UVC_ERR_NOMEM);
    }

    memset(buf, 0, need);
    memset(out->verify, 0, sizeof(out->verify));

    int attempts = 0;
    while (attempts++ < UVC_FRAME_MAX_RETRIES) {
        rc = GetFrame(ctx->sdk_dev, (char *)buf, (int)need,
                      out->verify, (int)sizeof(out->verify));
        if (rc == AC_ERR_SUCCESS) break;
        if (rc != AC_ERR_UVC_NEWFRAME_UNARRIVE) {
            UVC_LOGE("GetFrame 失败 rc=%d", rc);
            RETURN_UNLOCK(ctx, map_sdk_err(rc));
        }
        usleep(UVC_FRAME_WAIT_MS * 1000);
    }
    if (rc != AC_ERR_SUCCESS) {
        UVC_LOGE("GetFrame 超时，已重试 %d 次", attempts);
        RETURN_UNLOCK(ctx, UVC_ERR_TIMEOUT);
    }

    out->data   = (unsigned char *)buf;
    out->size   = need;
    out->width  = w;
    out->height = h;
    RETURN_UNLOCK(ctx, UVC_OK);
}

int uvc_save_frame_bmp(uvc_ctx_t *ctx, const char *path)
{
    if (!ctx || !path || !*path) return UVC_ERR_INVAL;

    int w = 0, h = 0;
    int err = uvc_get_resolution(ctx, &w, &h);
    if (err != UVC_OK) return err;

    const size_t sz = (size_t)w * (size_t)h * 4u;
    unsigned char *buf = (unsigned char *)malloc(sz);
    if (!buf) return UVC_ERR_NOMEM;

    uvc_frame_t fr;
    err = uvc_get_frame(ctx, buf, sz, &fr);
    if (err == UVC_OK) {
        int rc = uvc_bmp_write(path, fr.data, fr.width, fr.height);
        if (rc != 0) {
            UVC_LOGE("BMP 写入失败 rc=%d", rc);
            err = UVC_ERR_IO;
        } else {
            UVC_LOGI("帧已保存: %s (%dx%d)", path, fr.width, fr.height);
        }
    }
    free(buf);
    return err;
}
