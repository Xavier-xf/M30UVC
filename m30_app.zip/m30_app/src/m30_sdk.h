/*
 * m30_sdk.h  -  纯 C 前向声明，引用厂商 libAICameraModule 导出符号
 *
 *   厂商 ai_camera.h 是 C++ 格式（默认参数、无 #ifdef __cplusplus guard），
 *   无法在 C 编译单元中包含。所有符号均以 C linkage 导出，
 *   此处用纯 C 重新声明，链接器直接解析到同名未修饰符号。
 *
 *   基础框架版：仅声明生命周期 / 设备信息 / 帧获取 / 开关控制相关符号。
 */
#ifndef M30_SDK_H
#define M30_SDK_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ======================================================================== */
/*  日志管理                                                                 */
/* ======================================================================== */

int   SetLogConfig(int log_level, int log_target);

/* ======================================================================== */
/*  会话生命周期                                                             */
/* ======================================================================== */

void *Init(void);
int   DeInit(void *dev);

/* ======================================================================== */
/*  设备枚举与传输链路                                                       */
/* ======================================================================== */

int   EnumDevice(char *video_buf, int video_size,
                 char *serial_buf, int serial_size);
int   ConnectSerial(void *dev, const char *port_name);
int   ConnectCamera(void *dev, const char *media_name);
int   DisconnectSerial(void *dev);
int   DisconnectCamera(void *dev);

/* ======================================================================== */
/*  视频帧获取                                                               */
/* ======================================================================== */

int   GetFrame(void *dev, char *image_buf, int image_size,
               char *verify_buf, int verify_size);
int   GetResolution(void *dev, int *width, int *height);

/* ======================================================================== */
/*  系统诊断 / 设备信息                                                      */
/* ======================================================================== */

int   Ping(void *dev, const void *pTestData, unsigned int nTestDataLength);
int   GetDeviceVersion(void *dev, void *pVersion, unsigned int nLength);
int   GetDevSn(void *dev, char nMode, void *pDevSn, unsigned int nDevsnLength);
int   GetDevModel(void *dev, void *pDevModel, unsigned int nDevModelLength);
int   GetCpuTemperature(void *dev, unsigned int *nTemperature);

/* ======================================================================== */
/*  视频流配置 / 开关                                                        */
/* ======================================================================== */

/*
 * SetUvcSwitch - UVC 视频输出总开关
 * @nMode: 0=开启, 1=关闭 （注意：语义与布尔值相反）
 */
int   SetUvcSwitch(void *dev, char nMode);

/*
 * SetCameraStream - 打开/关闭指定摄像头
 * @isCloseCamera: 0x00=打开, 0x01=关闭 （注意：语义与布尔值相反）
 * @nCameraType:   0x00=RGB, 0x01=IR
 */
int   SetCameraStream(void *dev, char isCloseCamera, char nCameraType);

/*
 * GetCameraStream - 获取摄像头开关状态
 * @nCameraType:   0x00=RGB, 0x01=IR
 * @isOpenCamera:  输出 1=已打开, 0=已关闭
 */
int   GetCameraStream(void *dev, char nCameraType, unsigned char *isOpenCamera);

int   GetFrameRate(void *dev, unsigned int *pFrameRate);

/* ======================================================================== */
/*  厂商错误码                                                               */
/* ======================================================================== */
#define AC_ERR_SUCCESS                 0
#define AC_ERR_NOT_INIT               -1
#define AC_ERR_INIT_FAIL              -2
#define AC_ERR_ALREADY_INIT           -3
#define AC_ERR_INPUT_ARG              -4
#define AC_ERR_OUTPUT_ARG             -5
#define AC_ERR_COM_TIMEOUT            -6
#define AC_ERR_TLV_FORMAT             -7
#define AC_ERR_TLV_LENGTH             -8
#define AC_ERR_CALLBACK_REGISTERED    -9
#define AC_ERR_UVC_CONNECT           -10
#define AC_ERR_UVC_NEWFRAME_UNARRIVE -11
#define AC_ERR_SERIAL_CONNECT        -12

#ifdef __cplusplus
}
#endif
#endif /* M30_SDK_H */
